import hashlib, binascii, os
import uuid


def hash_password(password):
    """Hash a password for storing."""
    salt = hashlib.sha256(os.urandom(60)).hexdigest().encode('ascii')
    pwd_hash = hashlib.pbkdf2_hmac(
        hash_name='sha512',
        password=password.encode('utf-8'),
        salt=salt,
        iterations=100000)

    pwd_hash = binascii.hexlify(pwd_hash)
    return (salt + pwd_hash).decode('ascii')


def verify_password(stored_password, provided_password):
    """Verify a stored password against one provided by user"""
    salt = stored_password[:64]
    stored_password = stored_password[64:]
    pwd_hash = hashlib.pbkdf2_hmac(
        hash_name='sha512',
        password=provided_password.encode('utf-8'),
        salt=salt.encode('ascii'),
        iterations=100000)

    pwd_hash = binascii.hexlify(pwd_hash).decode('ascii')
    return pwd_hash == stored_password


def make_session_token():
    t = uuid.uuid1()
    return str(t)


def get_certificate_common_name(cert):
    if cert is None:
        return None

    for sub in cert.get("subject", ()):
        for key, value in sub:
            if key == "commonName":
                return value


if __name__ == "__main__":
    pwd_hash = hash_password('abcde')
    print("PWD for abcde: {}: {}".format(type(pwd_hash), pwd_hash))

    valid = verify_password(pwd_hash, 'abcde')
    print('PWD matches abcde: {}'.format(valid))

    valid = verify_password(pwd_hash, 'xyz')
    print('PWD matches xyz: {}'.format(valid))

    print('Token: {}'.format(make_session_token()))
