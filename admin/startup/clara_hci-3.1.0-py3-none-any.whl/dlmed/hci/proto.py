from datetime import datetime
from .table import Table
import json


class Buffer(object):

    def __init__(self):
        self.output = {
            'time': '{}'.format(datetime.now()),
            'data': []
        }

    def append_table(self, headers: [str]) -> Table:
        t = Table(headers)
        self.output['data'].append(
            {
                'type': 'table',
                'rows': t.rows
            }
        )
        return t

    def append_string(self, data: str):
        self.output['data'].append(
            {
                'type': 'string',
                'data': data
            }
        )

    def append_error(self, data: str):
        self.output['data'].append(
            {
                'type': 'error',
                'data': data
            }
        )

    def append_command(self, cmd: str):
        self.output['data'].append(
            {
                'type': 'command',
                'data': cmd
            }
        )

    def append_token(self, token: str):
        self.output['data'].append(
            {
                'type': 'token',
                'data': token
            }
        )

    def append_shutdown(self, msg: str):
        self.output['data'].append(
            {
                'type': 'shutdown',
                'data': msg
            }
        )

    def encode(self):
        if len(self.output['data']) <= 0:
            return None

        return json.dumps(self.output)

    def reset(self):
        self.output = {
            'time': '{}'.format(datetime.now()),
            'data': []
        }


def make_error(data: str):
    buf = Buffer()
    buf.append_error(data)
    return buf.output


def validate_proto(line: str):
    all_types = ['string', 'error', 'table', 'command', 'token', 'shutdown']
    types_with_data = ['string', 'error', 'command', 'token', 'shutdown']
    try:
        json_data = json.loads(line)
        assert isinstance(json_data, dict)
        assert 'data' in json_data
        data = json_data['data']
        assert isinstance(data, list)
        for item in data:
            assert isinstance(item, dict)
            assert 'type' in item
            it = item['type']
            assert it in all_types

            if it in types_with_data:
                assert 'data' in item
                assert isinstance(item['data'], str)
            elif it == 'table':
                assert 'rows' in item
                rows = item['rows']
                assert isinstance(rows, list)
                for row in rows:
                    assert isinstance(row, list)

        return json_data
    except:
        return None
