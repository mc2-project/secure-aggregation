from .reg import CommandFilter
from .constants import ConnProps
from dlmed.hci.conn import Connection
from dlmed.sec.audit import Auditor


class CommandAudit(CommandFilter):
    """
    Register this filter AFTER the login filter because it needs the user name established
    by the login filter!
    """

    def __init__(self, auditor: Auditor):
        CommandFilter.__init__(self)
        assert isinstance(auditor, Auditor), 'auditor must be Auditor'
        self.auditor = auditor

    def pre_command(self, conn: Connection, args: [str]):
        user_name = conn.get_prop(ConnProps.USER_NAME, '?')

        event_id = self.auditor.add_event(
            user=user_name,
            action=conn.command[:100],  # at most 100 chars
        )

        conn.set_prop(ConnProps.EVENT_ID, event_id)
        return True
