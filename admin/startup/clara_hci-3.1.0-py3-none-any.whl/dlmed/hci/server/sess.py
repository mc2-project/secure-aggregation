from dlmed.hci.security import make_session_token
from dlmed.hci.reg import CommandSpec, CommandModuleSpec, CommandModule
from dlmed.hci.conn import Connection
from dlmed.utils.time_utils import time_to_string
import threading
import time


class Session(object):

    def __init__(self):
        self.user_name = None
        self.start_time = None
        self.last_active_time = None
        self.token = None

    def mark_active(self):
        self.last_active_time = time.time()


class SessionManager(CommandModule):

    def __init__(self, idle_timeout=3600, monitor_interval=5):
        if monitor_interval <= 0:
            monitor_interval = 5

        self.sess_update_lock = threading.Lock()
        self.sessions = {}  # token => Session
        self.idle_timeout = idle_timeout
        self.monitor_interval = monitor_interval
        self.asked_to_stop = False
        self.monitor = threading.Thread(target=self.monitor_sessions)
        self.monitor.start()

    def monitor_sessions(self):
        while True:
            # print('checking for dead sessions ...')
            if self.asked_to_stop:
                break

            dead_sess = None
            for _, sess in self.sessions.items():
                time_passed = time.time() - sess.last_active_time
                # print('time passed: {} secs'.format(time_passed))
                if time_passed > self.idle_timeout:
                    dead_sess = sess
                    break

            if dead_sess:
                # print('ending dead session {}'.format(dead_sess.token))
                self.end_session(dead_sess.token)
            else:
                # print('no dead sessions found')
                pass

            time.sleep(self.monitor_interval)

    def shutdown(self):
        self.asked_to_stop = True
        self.monitor.join(timeout=10)

    def create_session(self, user_name):
        token = make_session_token()
        sess = Session()
        sess.user_name = user_name
        sess.start_time = time.time()
        sess.last_active_time = sess.start_time
        sess.token = token
        with self.sess_update_lock:
            self.sessions[token] = sess
        return sess

    def get_session(self, token: str):
        with self.sess_update_lock:
            return self.sessions.get(token)

    def get_sessions(self):
        result = []
        with self.sess_update_lock:
            for _, s in self.sessions.items():
                result.append(s)
        return result

    def end_session(self, token):
        with self.sess_update_lock:
            self.sessions.pop(token, None)

    def get_spec(self):
        return CommandModuleSpec(
            name='sess',
            cmd_specs=[
                CommandSpec(
                    name='list_sessions',
                    description='list user sessions',
                    usage='list_sessions',
                    handler_func=self.handle_list_sessions,
                    visible=True
                )
            ]
        )

    def handle_list_sessions(self, conn: Connection, args: [str]):
        sess_list = list(self.sessions.values())
        sess_list.sort(key=lambda x: x.user_name, reverse=False)
        table = conn.append_table(['User', 'Session ID', 'Start', 'Last Active', 'Idle'])
        for s in sess_list:
            table.add_row([s.user_name,
                           '{}'.format(s.token),
                           time_to_string(s.start_time),
                           time_to_string(s.last_active_time),
                           '{}'.format(time.time() - s.last_active_time)])
