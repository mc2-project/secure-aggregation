import socketserver
import threading
import traceback
import ssl

from dlmed.hci.conn import Connection, receive_til_end
from .reg import ServerCommandRegister
from dlmed.hci.proto import validate_proto
from dlmed.hci.security import get_certificate_common_name


class _MsgHandler(socketserver.BaseRequestHandler):

    def handle(self):
        try:
            conn = Connection(self.request, self.server)

            if self.server.use_ssl:
                cn = get_certificate_common_name(self.request.getpeercert())
                conn.set_prop('_client_cn', cn)
                valid = self.server.validate_client_cn(cn)
            else:
                valid = True

            if not valid:
                conn.append_error('authentication error')
            else:
                req = receive_til_end(self.request).strip()
                command = None
                req_json = validate_proto(req)
                conn.request = req_json
                if req_json is not None:
                    data = req_json['data']
                    for item in data:
                        it = item['type']
                        if it == 'command':
                            command = item['data']
                            break

                    if command is None:
                        conn.append_error('protocol violation')
                    else:
                        self.server.cmd_reg.process_command(conn, command)
                else:
                    # not json encoded
                    conn.append_error('protocol violation')

            if not conn.ended:
                conn.close()
        except:
            traceback.print_exc()


def initialize_hci():
    socketserver.TCPServer.allow_reuse_address = True


class AdminServer(socketserver.ThreadingTCPServer):
    # faster re-binding
    allow_reuse_address = True

    # make this bigger than five
    request_queue_size = 10

    # kick connections when we exit
    daemon_threads = True

    def __init__(self,
                 cmd_reg: ServerCommandRegister,
                 host, port,
                 ca_cert=None,
                 server_cert=None,
                 server_key=None,
                 accepted_client_cns=None):

        socketserver.TCPServer.__init__(self, (host, port), _MsgHandler, False)

        self.use_ssl = False
        if ca_cert and server_cert:
            if accepted_client_cns:
                assert isinstance(accepted_client_cns, list), 'accepted_client_cns must be list'

            ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            ctx.verify_mode = ssl.CERT_REQUIRED
            ctx.load_verify_locations(ca_cert)
            ctx.load_cert_chain(
                certfile=server_cert,
                keyfile=server_key
            )

            # replace the socket with an ssl version of itself
            self.socket = ctx.wrap_socket(self.socket, server_side=True)
            self.use_ssl = True

        # bind the socket and start the server
        self.server_bind()
        self.server_activate()

        self._thread = None
        self.host = host
        self.port = port
        self.accepted_client_cns = accepted_client_cns
        self.cmd_reg = cmd_reg
        cmd_reg.finalize()

    def validate_client_cn(self, cn):
        if self.accepted_client_cns:
            return cn in self.accepted_client_cns
        else:
            return True

    def stop(self):
        self.shutdown()
        self.cmd_reg.close()

        if self._thread.is_alive():
            self._thread.join()

        print('Admin Server {} on Port {} shutdown!'.format(self.host, self.port))

    def start(self):
        if self._thread is None:
            self._thread = threading.Thread(target=_start_server, args=(self,))

        if not self._thread.is_alive():
            self._thread.start()

    def _run(self):
        print('Starting Admin Server {} on Port {}'.format(self.host, self.port))
        self.serve_forever()


def _start_server(s: AdminServer):
    s._run()
