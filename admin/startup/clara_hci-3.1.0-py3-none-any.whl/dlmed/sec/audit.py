from datetime import datetime
import os
import uuid


class Auditor(object):

    def __init__(self, audit_file_name: str):
        assert isinstance(audit_file_name, str), 'audit_file_name must be str'
        if os.path.exists(audit_file_name):
            assert os.path.isfile(audit_file_name), 'audit_file_name is not a valid file'

        # create/open the file
        self.audit_file = open(audit_file_name, 'a')

    def add_event(self, user: str, action: str, ref: str='', msg: str='') -> str:
        event_id = uuid.uuid4()
        event_id_str = '{}'.format(event_id)

        if len(ref) > 0:
            ref = ' [R:{}] '.format(ref)
        else:
            ref = ' '

        if len(msg) > 0:
            msg = ' [M:{}]'.format(msg)

        line = '[E:{}]{}[T:{}] [U:{}] [A:{}]{}\n'.format(
            event_id, ref, datetime.now(), user, action, msg)
        self.audit_file.write(line)
        self.audit_file.flush()
        return event_id_str

    def close(self):
        if self.audit_file is not None:
            self.audit_file.close()
            self.audit_file = None


class AuditService(object):

    the_auditor = None

    @staticmethod
    def initialize(audit_file_name: str):
        if not AuditService.the_auditor:
            AuditService.the_auditor = Auditor(audit_file_name)
        return AuditService.the_auditor

    @staticmethod
    def get_auditor():
        return AuditService.the_auditor

    @staticmethod
    def add_event(user: str, action: str, ref: str='', msg: str='') -> str:
        if not AuditService.the_auditor:
            return ''
        return AuditService.the_auditor.add_event(user, action, ref, msg)

    @staticmethod
    def close():
        if AuditService.the_auditor:
            AuditService.the_auditor.close()
