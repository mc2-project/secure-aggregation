import threading


class SimpleContext(object):

    def __init__(self):
        self.props = {}

    def set_prop(self, key, value):
        self.props[key] = value

    def set_props(self, props: dict):
        if props:
            self.props.update(props)

    def len(self):
        return len(self.props)

    def get_prop(self, key, default=None):
        return self.props.get(key, default)

    def clear_props(self):
        self.props = {}


class BaseContext(SimpleContext):

    def __init__(self):
        SimpleContext.__init__(self)
        self.asked_to_stop = False
        self._update_lock = threading.Lock()

    def ask_to_stop(self):
        self.asked_to_stop = True

    def set_prop(self, key, value):
        with self._update_lock:
            SimpleContext.set_prop(self, key, value)

    def set_props(self, props: dict):
        if not props:
            return

        with self._update_lock:
            SimpleContext.set_props(self, props)

    def len(self):
        with self._update_lock:
            return SimpleContext.len(self)

    def get_prop(self, key, default=None):
        with self._update_lock:
            return SimpleContext.get_prop(self, key, default)

    def clear_props(self):
        with self._update_lock:
            SimpleContext.clear_props(self)
